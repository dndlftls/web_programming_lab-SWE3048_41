function formatPrice(value) {
  return value.toLocaleString("ko-KR") + "원";
}

function updateCartTotals() {
  let grandTotal = 0; // Total Amount Variable

  // TODO: Updating Total Amount
  // 
  
  const grandTotalEl = document.getElementById("grand-total"); // Total Amount Item in HTML
  grandTotalEl.textContent = formatPrice(grandTotal); // Formatting Text
}

// Increasing Amount of Item
function increaseQty(itemEl) {
  const qtyEl = itemEl.querySelector(".qty-value");
  // TODO : Increasing Amount
}

// Decreasing Amount of Item
function decreaseQty(itemEl) {
  const qtyEl = itemEl.querySelector(".qty-value");
  // TODO : Decreasing Amount
}

// EventListeners (When Button clicked) --> implemented
function setupEventListeners() {
  const cart = document.querySelector(".cart-items");

  cart.addEventListener("click", (e) => {
    const target = e.target;

    if (target.classList.contains("btn-increase")) {
      const itemEl = target.closest(".cart-item");
      increaseQty(itemEl);
      updateCartTotals();
    }

    if (target.classList.contains("btn-decrease")) {
      const itemEl = target.closest(".cart-item");
      decreaseQty(itemEl);
      updateCartTotals();
    }
  });
}

// Add Initial EventListeners -> implemented
document.addEventListener("DOMContentLoaded", () => {
  setupEventListeners();
  updateCartTotals();
});