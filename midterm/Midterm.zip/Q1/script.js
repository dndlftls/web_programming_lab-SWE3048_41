const handleClick = () => {
  // Todo : Changing Background Color
  alert("Background color will change!");
};

const btn = document.getElementById("clickme");
// TODO : Add Event Listener