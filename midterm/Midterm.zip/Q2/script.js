document.addEventListener("DOMContentLoaded", () => {
  // .Calculator button = the only button inside your form/card
  const button = document.querySelector(".Calculator button");
  if (button) button.addEventListener("click", calculateBMI);
});

function calculateBMI() {
  const weight = parseFloat(document.getElementById("weight").value);
  const height = parseFloat(document.getElementById("height").value) / 100; 

  // TODO : Calculate BMI and use displayResult function to show the result.
}

function displayResult(bmi) {
  const resultDiv = document.getElementById("final-result");
  let category = "";

  // TODO : Display Result of BMI
}
