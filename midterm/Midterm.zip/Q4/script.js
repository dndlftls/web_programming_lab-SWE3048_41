document.getElementById("processBtn").addEventListener("click", function () {
  const input = document.getElementById("arrayInput").value.trim();

  // TODO : Move zeros to end while maintaining order of non-zeros
  let nonZero; // TODO : Assign nonZero's value
  let zeros; // TODO : Assign zeros' value
  const result = [...nonZero, ...zeros];
  document.getElementById("resultBox").textContent = `[ ${result.join(", ")} ]`;
});